<?php

namespace CartRabbit\Helper;
use CartRabbit\Models\Checkout;

/**
 * Class User
 * @package CartRabbit\Helper
 */
class User
{

}

