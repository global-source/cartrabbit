<?php

namespace CartRabbit\Helper;

class CoreHelper
{

    public function getSiteAddress(){

    }

}

