<?php

namespace CartRabbit\Models;

use Corcel\Post as Post;
use Illuminate\Database\Eloquent\Model as Eloquent;
use CartRabbit\Helper\Util;

/**
 * Class products
 * @package CartRabbit\Models
 */
class SimpleProduct extends Eloquent
{


}