<?php

namespace CartRabbit\Models;

use Corcel\Term;

class wp_Term extends Term
{
    public function getSlug(){

    }

}