<?php

namespace CartRabbit\Models;

use Corcel\Post as Post;

/**
 * Class products
 * @package CartRabbit\Models
 */
class Configuration extends Post
{

    /**
     * Cart constructor.
     */
    public function __construct()
    {

    }
}